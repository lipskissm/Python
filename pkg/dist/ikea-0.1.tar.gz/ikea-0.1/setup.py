from setuptools import setup, find_packages

setup(
    name='Ikea',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        # Add any dependencies your package requires
        # For example:
        # 'numpy',
    ],
)
